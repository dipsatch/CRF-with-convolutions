import torch
import torch.nn as nn


class Conv(nn.module):
    """
    Convolution layer.
    """
    def __init__(self):
        super(Conv, self).__init__()


    def init_params(self):
        """
        Initialize the layer parameters
        :return:
        """

    def forward(self):
        """
        Forward pass
        :return:
        """

    def backward(self):
        """
        Backward pass
        :return:
        """




